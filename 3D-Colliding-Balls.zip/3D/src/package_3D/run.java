package package_3D;
/**
 * @author burakerken
 *
 */
public class run {

	public static void main(String[] args) {
		new Frame();
	}
}